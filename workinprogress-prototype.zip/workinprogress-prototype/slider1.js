var audio = document.getElementById("audioMusic");
            function bell() {
            audio.play();
            } 